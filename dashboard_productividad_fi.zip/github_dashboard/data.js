/*
  ============================================================================
  DATOS DEL DASHBOARD — Fertilidad Integral
  ============================================================================
  ESTE ES EL ÚNICO ARCHIVO QUE DEBES EDITAR CADA MES.
  No toques index.html ni chart.min.js.

  Cómo actualizar (cada corte de mes, ej. cierre de septiembre):
    1. Añade el nuevo mes real al final de cada arreglo "hist" (histórico).
    2. Actualiza "ago" -> renómbralo mentalmente como "mes actual" y cambia
       su valor por el real acumulado a la fecha de corte.
    3. Actualiza "proy" con la nueva proyección a cierre de mes.
    4. Actualiza vsLM (vs. mes anterior) y vsU3M (vs. promedio de los
       últimos 3 meses cerrados) — ambos en % (ej. 22 significa +22%).
    5. Actualiza servicios[], highlights[], hubspot y consultas_ranking
       con los nuevos hallazgos del mes.
    6. Guarda el archivo y vuelve a subirlo a GitHub (ver README.md).

  Formato de números: usa punto decimal (12.7, no 12,7). Sin comas de miles.
  ============================================================================
*/

window.DATA = {
  corte: "24-ago-2026",
  meses_hist: ["Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul"],
  mes_actual: "Ago",

  // ------------------------------------------------------------------------
  // TOTAL COMPAÑÍA (Ingresos = dato oficial del corte; Atenciones y
  // Pacientes Únicos = suma de las 3 sedes, ya que se proyectan sede por
  // sede en el reporte fuente)
  // ------------------------------------------------------------------------
  total: {
    nombre: "Todas las sedes",
    ingresos: { hist: [12.0, 12.0, 13.2, 12.5, 12.8, 12.1, 12.0], actual: 12.7, proy: 14.6, vsLM: 22, vsU3M: 19, nota: "$2.6M vs LM, $2.3M vs U3M" },
    atenciones: { hist: [2494, 2288, 2556, 2513, 2547, 2320, 2547], actual: 2611, proy: 3065, vsLM: 20, vsU3M: 24, nota: "suma CDMX+GDL+MTP" },
    pacientes: { hist: [589, 613, 735, 773, 762, 732, 741], actual: 837, proy: 1024, vsLM: 38, vsU3M: 37, nota: "suma CDMX+GDL+MTP" },
    consultas: { hist: [168, 167, 235, 220, 225, 271, 255], real: 248, agendado: 92, proy: 340, vsLM: 33, vsU3M: 36 },
  },

  // ------------------------------------------------------------------------
  // POR SEDE
  // ------------------------------------------------------------------------
  sedes: {
    CDMX: {
      nombre: "Ciudad de México",
      ingresos: { hist: [10.2, 9.8, 10.3, 10.5, 10.2, 9.3, 10.0], actual: 10.0, proy: 11.5, vsLM: 15, vsU3M: 17 },
      atenciones: { hist: [2095, 1788, 1923, 2009, 1962, 1706, 1897], actual: 1819, proy: 2107, vsLM: 11, vsU3M: 14 },
      pacientes: { hist: [455, 470, 530, 587, 566, 500, 506], actual: 527, proy: 641, vsLM: 27, vsU3M: 22 },
      consultas: { hist: [127, 105, 144, 145, 133, 169, 141], real: 105, agendado: 44, proy: 149, vsLM: 6, vsU3M: 1, top_cat: "Consulta primera vez", top_n: 82 },
    },
    GDL: {
      nombre: "Guadalajara",
      ingresos: { hist: [1.3, 1.5, 2.1, 1.5, 1.9, 2.4, 1.5], actual: 1.9, proy: 2.2, vsLM: 51, vsU3M: 15 },
      atenciones: { hist: [261, 311, 420, 326, 416, 507, 427], actual: 569, proy: 677, vsLM: 58, vsU3M: 50 },
      pacientes: { hist: [103, 98, 158, 136, 163, 195, 175], actual: 232, proy: 295, vsLM: 69, vsU3M: 66 },
      consultas: { hist: [33, 41, 75, 55, 79, 93, 87], real: 106, agendado: 32, proy: 138, vsLM: 59, vsU3M: 60, top_cat: "Consulta primera vez", top_n: 32 },
    },
    MTP: {
      nombre: "Metepec",
      ingresos: { hist: [0.5, 0.7, 0.8, 0.5, 0.6, 0.4, 0.5], actual: 0.8, proy: 0.8, vsLM: 63, vsU3M: 58 },
      atenciones: { hist: [138, 189, 213, 178, 169, 107, 223], actual: 223, proy: 281, vsLM: 26, vsU3M: 69 },
      pacientes: { hist: [31, 45, 47, 50, 33, 37, 60], actual: 78, proy: 88, vsLM: 47, vsU3M: 103 },
      consultas: { hist: [8, 21, 16, 20, 13, 9, 27], real: 37, agendado: 16, proy: 53, vsLM: 96, vsU3M: 225, top_cat: "Consulta primera vez", top_n: 32 },
    },
  },

  // ------------------------------------------------------------------------
  // SERVICIOS — Ingresos por servicio, proyectado (MDP), vs LM y vs U3M
  // ------------------------------------------------------------------------
  servicios: {
    total: [
      { nombre: "Tratamientos FIV/ICSI", valor: 4.3, vsLM: 18, vsU3M: null },
      { nombre: "Farmacia", valor: 2.9, vsLM: -2, vsU3M: null },
      { nombre: "Congelación de Gametos", valor: 2.6, vsLM: 26, vsU3M: null },
      { nombre: "Laboratorio", valor: 2.7, vsLM: 42, vsU3M: null },
      { nombre: "Subrogación", valor: 1.3, vsLM: 135, vsU3M: null },
      { nombre: "Consultas", valor: 0.4, vsLM: 38, vsU3M: null },
    ],
    CDMX: [
      { nombre: "Tratamientos FIV/ICSI", valor: 3.5, vsLM: 9, vsU3M: 15 },
      { nombre: "Congelación de Gametos", valor: 1.9, vsLM: 4, vsU3M: -14 },
      { nombre: "Farmacia", valor: 2.4, vsLM: -5, vsU3M: 1 },
      { nombre: "Subrogación", valor: 1.3, vsLM: 135, vsU3M: 205 },
      { nombre: "Laboratorio", valor: 2.1, vsLM: 49, vsU3M: 48 },
      { nombre: "Consultas", valor: 0.2, vsLM: 5, vsU3M: -1 },
    ],
    GDL: [
      { nombre: "Tratamientos FIV/ICSI", valor: 0.6, vsLM: 79, vsU3M: -12 },
      { nombre: "Congelación de Gametos", valor: 0.6, vsLM: 164, vsU3M: 73 },
      { nombre: "Farmacia", valor: 0.4, vsLM: 31, vsU3M: 22 },
      { nombre: "Laboratorio", valor: 0.5, vsLM: 2, vsU3M: 7 },
      { nombre: "Consultas", valor: 0.2, vsLM: 112, vsU3M: 89 },
      { nombre: "Procedimientos / Quirúrgicos", valor: 0.0, vsLM: -44, vsU3M: -45 },
    ],
    MTP: [
      { nombre: "Farmacia", valor: 0.2, vsLM: -11, vsU3M: -6 },
      { nombre: "Tratamientos FIV/ICSI", valor: 0.2, vsLM: 72, vsU3M: 68 },
      { nombre: "Laboratorio", valor: 0.2, vsLM: 172, vsU3M: 180 },
      { nombre: "Congelación de Gametos", valor: 0.1, vsLM: 1088, vsU3M: 161 },
      { nombre: "Procedimientos / Quirúrgicos", valor: 0.0, vsLM: null, vsU3M: null, nuevo: true },
      { nombre: "Consultas", valor: 0.0, vsLM: 1, vsU3M: -4 },
    ],
  },

  // ------------------------------------------------------------------------
  // HIGHLIGHTS — hallazgos cualitativos del corte (texto libre, editable)
  // ------------------------------------------------------------------------
  highlights: {
    total: [
      "Ingresos: $14.6M proy., +22% vs LM. Pipeline CDMX: FIV +$238k, Laboratorio +$506k.",
      "Laboratorio (+42%): FI +32%/día y Clínico +23%/día; Externo cae -26%/día. CDMX: $506k pipeline sin detalle (validar).",
      "Metepec: +63% vs LM — Laboratorio FI (PGT-A) +$153k impulsa el mes; Farmacia -$56k y Procedimientos -$7k por pipeline conocido.",
      "Guadalajara: +51% vs LM — motor Congelación (+188%/día); Donación cae a $0 (vs $94.8k jul, 5 casos) — validar agenda.",
      "Subrogación (CDMX): $1.3M, +135% vs LM — 7 casos en agosto, liderados por 1 paquete Frozen Donor ($546k) + 3 All Inclusive.",
    ],
    CDMX: [
      "Donación: $418k en agosto (4 casos; 2 óvulos FI de alto ticket: $250k y $146.5k) vs $22k en julio — validar recurrencia antes de proyectar a septiembre.",
      "Inseminación Intrauterina (IIU): -26%/día vs LM — única subclasificación en descenso sostenido dentro de Laboratorio/FIV; dar seguimiento.",
    ],
    GDL: [
      "Donación de esperma: $0 en agosto vs $94.8k en julio (5 casos) — el servicio se detuvo por completo; investigar agenda y disponibilidad de donantes.",
      "FIV/ICSI (+266%/día) y Congelación (+188%/día) son el motor del mes — validar que la capacidad de laboratorio soporte el ritmo.",
    ],
    MTP: [
      "Laboratorio FI (PGT-A) +$153k/día impulsa Laboratorio +172% vs LM — principal motor de crecimiento de la sede.",
      "Laboratorio Clínico cae -39%/día y Externo -28%/día vs LM — volumen aún bajo (sede pequeña) pero tendencia a vigilar.",
    ],
  },

  // ------------------------------------------------------------------------
  // RANKING DE CONSULTAS POR AGRUPACIÓN (Agosto = real + agendado), vs LM
  // ------------------------------------------------------------------------
  consultas_ranking: {
    total: [
      { nombre: "Consulta primera vez", valor: 146, vsLM: 5 },
      { nombre: "Fertility Check up Mujeres", valor: 59, vsLM: 69 },
      { nombre: "Check up Ginecológico", valor: 54, vsLM: 26 },
      { nombre: "Check-up SOP", valor: 33, vsLM: 267 },
      { nombre: "Fertility Check up Parejas", valor: 26, vsLM: 117 },
      { nombre: "Consulta 1a Vez IP's", valor: 7, vsLM: 17 },
      { nombre: "Consulta ginecológica", valor: 4, vsLM: 100 },
    ],
    CDMX: [
      { nombre: "Consulta primera vez", valor: 82, vsLM: -7 },
      { nombre: "Fertility Check up Mujeres", valor: 33, vsLM: 74 },
      { nombre: "Check up Ginecológico", valor: 12, vsLM: -25 },
      { nombre: "Fertility Check up Parejas", valor: 9, vsLM: 12 },
      { nombre: "Consulta 1a Vez IP's", valor: 7, vsLM: 17 },
    ],
    GDL: [
      { nombre: "Consulta primera vez", valor: 32, vsLM: 10 },
      { nombre: "Check-up SOP", valor: 30, vsLM: 233 },
      { nombre: "Check up Ginecológico", valor: 29, vsLM: 16 },
      { nombre: "Fertility Check up Mujeres", valor: 25, vsLM: 79 },
      { nombre: "Fertility Check up Parejas", valor: 13, vsLM: 225 },
    ],
    MTP: [
      { nombre: "Consulta primera vez", valor: 32, vsLM: 46 },
      { nombre: "Check up Ginecológico", valor: 13, vsLM: 550 },
      { nombre: "Fertility Check up Parejas", valor: 4, vsLM: null, nuevo: true },
      { nombre: "Consulta ginecológica", valor: 3, vsLM: 200 },
      { nombre: "Fertility Check up Mujeres", valor: 1, vsLM: -50 },
    ],
  },

  // ------------------------------------------------------------------------
  // HUBSPOT — Pipeline "Interesa2". Leads por fecha de creación, citas por
  // Fecha_CitaAgendada_Int2. Corte 24-ago-2026.
  // ------------------------------------------------------------------------
  hubspot: {
    leads: { hist: [837, 1068, 1023, 1015, 1759, 1438, 1539], actual: 1531 },
    citas: { hist: [178, 220, 316, 330, 362, 310, 407], actual: 380 },
    conversion_pct: { hist: [21, 21, 31, 33, 21, 22, 26], actual: 25 },
    conversion_por_sede: {
      // Agosto (parcial, corte 24-ago) vs Total acumulado 2026
      CDMX: { agosto: 25, total2026: 28 },
      GDL: { agosto: 21, total2026: 20 },
      MTP: { agosto: 33, total2026: 30 },
    },
    cohortes: [
      { mes: "Ene-26", leads: 837, m0: 21, m1: 1, m2: 1, sin: 76 },
      { mes: "Feb-26", leads: 1068, m0: 19, m1: 2, m2: 0, sin: 78 },
      { mes: "Mar-26", leads: 1023, m0: 28, m1: 1, m2: 1, sin: 70 },
      { mes: "Abr-26", leads: 1015, m0: 31, m1: 3, m2: 0, sin: 66 },
      { mes: "May-26", leads: 1759, m0: 19, m1: 1, m2: 1, sin: 80 },
      { mes: "Jun-26", leads: 1438, m0: 20, m1: 2, m2: 0, sin: 78 },
      { mes: "Jul-26", leads: 1539, m0: 24, m1: 2, m2: 0, sin: 74 },
      { mes: "Ago-26", leads: 1531, m0: 22, m1: 0, m2: 0, sin: 78 },
    ],
  },
};
